import pandas as pd
import os
import json, time
import paho.mqtt.client as mqtt
from flask import Flask, request, render_template, Response
from flask_restful import Resource, Api
import threading
from first_app import GeneratorThread, DataChanger
import requests


app = Flask(__name__)
api = Api(app)

class Path:
    path = {}

    def __init__(self):
        pass

    def change(self,name,type):
        self.path[name] = type


@app.route('/',methods=['GET', 'POST'])
def home():
    p = Path()
    if request.method == 'POST':
        try:
            if request.form['path'] and not  request.form['path'] in  p.path:
                p.change(request.form['path'],'off')

        except:
            pass



    return render_template("zazrzadca.html", datas=Path.path)




class Setter(Resource):


    data = []
    freq = int()
    path = str()
    protocol = str()
    name = ""
    workin = 'off'

    def get(self,name):
        self.name = name

        return Response(response=render_template('index.html', protocol = self.protocol, name = self.name, frequency = self.freq))

    def post(self,name):
        p = Path()
        p.change(name, 'on')
        self.path = 'dane/' + name
        self.protocol = request.form['protocol']
        self.freq = request.form['frequency']
        self.gt = GeneratorThread(self.protocol, int(self.freq), self.path, name, "test.mosquitto.org")


        return Response(response=render_template('index.html', protocol = self.protocol, name = name, frequency = self.freq))





api.add_resource(Setter, '/data', '/data/<name>')
api.add_resource(DataChanger, '/res/dane', '/res/dane/<name>')

if __name__ == "__main__":
    app.run(debug=True)